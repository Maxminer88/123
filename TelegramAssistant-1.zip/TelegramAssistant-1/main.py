import os
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from dotenv import load_dotenv
import math
import random

load_dotenv()
TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')

# Состояние пользователей (для викторины)
user_states = {}

# Система оценивания пользователей
user_scores = {}

# Вопросы для викторины
quiz_questions = [
    {
        "question": "Что такое ВВП?",
        "options": ["А) Валовой внутренний продукт", "Б) Валовой внешний продукт", "В) Внутренний валовой процент"],
        "answer": "А"
    },
    {
        "question": "Что такое флотирование валюты?",
        "options": ["А) Установленный курс", "Б) Свободное установление курса", "В) Поддержка курса"],
        "answer": "Б"
    },
    {
        "question": "Какой из следующих показателей является опережающим индикатором?",
        "options": ["А) Уровень безработицы", "Б) Индекс производственной активности", "В) Инфляция"],
        "answer": "Б"
    },
    {
        "question": "Что такое валютный курс?",
        "options": ["А) Цена одной валюты в терминах другой", "Б) Уровень инфляции в стране", "В) Рейтинг финансовых институтов"],
        "answer": "А"
    },
    {
        "question": "Какое влияние оказывает снижение процентной ставки?",
        "options": ["А) Увеличивает инвестиции", "Б) Увеличивает инфляцию", "В) Снижает спрос на кредит"],
        "answer": "А"
    },
    {
        "question": "Что такое экономический цикл?",
        "options": ["А) Периоды роста и спада экономики", "Б) Устойчивое экономическое развитие", "В) Нестабильность цен"],
        "answer": "А"
    },
    {
        "question": "Что такое динамика цен?",
        "options": ["А) Изменение общего уровня цен", "Б) Колебание валютного курса", "В) Темп роста экономики"],
        "answer": "А"
    },
    {
        "question": "Что такое экономическая загрязнённость?",
        "options": ["А) Рост производства", "Б) Увеличение экологии", "В) Влияние производства на природу"],
        "answer": "В"
    },
    {
        "question": "Какой стимул используется для повышения инвестиций?",
        "options": ["А) Снижение налогов", "Б) Увеличение государственных расходов", "В) Увеличение процентных ставок"],
        "answer": "А"
    },
    {
        "question": "Что измеряет ставки рефинансирования?",
        "options": ["А) Условия кредитования", "Б) Стоимость денег для банков", "В) Уровень заимствований"],
        "answer": "Б"
    },
    {
        "question": "Какое из утверждений верно для монетарной политики?",
        "options": ["А) Ориентирована на налоги", "Б) Ориентирована на денежную массу", "В) Ориентирована на социальные программы"],
        "answer": "Б"
    },
    {
        "question": "Какая организация устанавливает ключевую ставку в России?",
        "options": ["А) Минфин", "Б) Центральный банк", "В) Правительство"],
        "answer": "Б"
    },
    {
        "question": "Что означает рост инфляции?",
        "options": ["А) Снижение цен", "Б) Рост цен", "В) Стабильность цен"],
        "answer": "Б"
    },
    {
        "question": "Что такое дефляция?",
        "options": ["А) Рост цен", "Б) Снижение цен", "В) Стабильность цен"],
        "answer": "Б"
    },
    {
        "question": "Какой показатель характеризует безработицу?",
        "options": ["А) Уровень безработицы", "Б) Индекс цен", "В) Валютный курс"],
        "answer": "А"
    },
    {
        "question": "Что такое девальвация рубля?",
        "options": ["А) Укрепление рубля", "Б) Ослабление рубля", "В) Стабильность курса"],
        "answer": "Б"
    },
    {
        "question": "Как называется общая стоимость всех товаров и услуг в стране?",
        "options": ["А) ВНП", "Б) ВВП", "В) НД"],
        "answer": "Б"
    },
    {
        "question": "Что показывает индекс потребительских цен?",
        "options": ["А) Динамику цен на товары и услуги", "Б) Уровень безработицы", "В) Объём экспорта"],
        "answer": "А"
    },
    {
        "question": "Какая валюта является резервной в мире?",
        "options": ["А) Евро", "Б) Доллар США", "В) Британский фунт"],
        "answer": "Б"
    },
    {
        "question": "Что такое рецессия?",
        "options": ["А) Экономический рост", "Б) Экономический спад", "В) Стабильная экономика"],
        "answer": "Б"
    },
    {
        "question": "Кто является главой Центрального банка России?",
        "options": ["А) Министр финансов", "Б) Председатель ЦБ РФ", "В) Премьер-министр"],
        "answer": "Б"
    },
    {
        "question": "Что такое фискальная политика?",
        "options": ["А) Политика в области налогов и расходов", "Б) Денежная политика", "В) Торговая политика"],
        "answer": "А"
    },
    {
        "question": "Какой налог является прямым?",
        "options": ["А) НДС", "Б) Подоходный налог", "В) Акциз"],
        "answer": "Б"
    },
    {
        "question": "Что показывает коэффициент Джини?",
        "options": ["А) Уровень инфляции", "Б) Неравенство доходов", "В) Экономический рост"],
        "answer": "Б"
    },
    {
        "question": "Какая организация публикует данные о ВВП России?",
        "options": ["А) Росстат", "Б) ЦБ РФ", "В) Минэкономразвития"],
        "answer": "А"
    },
    {
        "question": "Что такое мультипликатор в экономике?",
        "options": ["А) Коэффициент роста инвестиций", "Б) Коэффициент увеличения ВВП", "В) Коэффициент инфляции"],
        "answer": "Б"
    },
    {
        "question": "Какой показатель характеризует покупательную способность валюты?",
        "options": ["А) Номинальный курс", "Б) Реальный курс", "В) Официальный курс"],
        "answer": "Б"
    },
    {
        "question": "Что такое стагфляция?",
        "options": ["А) Рост + инфляция", "Б) Спад + дефляция", "В) Стагнация + инфляция"],
        "answer": "В"
    },
    {
        "question": "Какой вид безработицы связан с поиском новой работы?",
        "options": ["А) Структурная", "Б) Фрикционная", "В) Циклическая"],
        "answer": "Б"
    },
    {
        "question": "Что такое ликвидность?",
        "options": ["А) Способность активов превращаться в деньги", "Б) Доходность инвестиций", "В) Уровень риска"],
        "answer": "А"
    },
    {
        "question": "Что такое торговый баланс?",
        "options": ["А) Разность между экспортом и импортом", "Б) Общий объем торговли", "В) Курс национальной валюты"],
        "answer": "А"
    },
    {
        "question": "Какую функцию выполняют центральные банки?",
        "options": ["А) Регулирование денежного обращения", "Б) Налогообложение", "В) Социальная поддержка"],
        "answer": "А"
    },
    {
        "question": "Что такое эмиссия денег?",
        "options": ["А) Изъятие денег из обращения", "Б) Выпуск новых денег", "В) Обмен валют"],
        "answer": "Б"
    },
    {
        "question": "Какой показатель измеряет общий уровень цен в экономике?",
        "options": ["А) ИПЦ (Индекс потребительских цен)", "Б) ВВП", "В) Уровень безработицы"],
        "answer": "А"
    },
    {
        "question": "Что означает профицит бюджета?",
        "options": ["А) Превышение расходов над доходами", "Б) Превышение доходов над расходами", "В) Равенство доходов и расходов"],
        "answer": "Б"
    }
]

# Функция для создания главной клавиатуры
def get_main_keyboard():
    keyboard = [
        [KeyboardButton("🧠 Начать викторину"), KeyboardButton("📊 Моя статистика")],
        [KeyboardButton("🏆 Рейтинг"), KeyboardButton("❓ Помощь")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# Функция викторины
async def quiz_question(update: Update):
    user_id = update.effective_user.id
    question = random.choice(quiz_questions)
    
    # Сохраняем состояние пользователя
    user_states[user_id] = {
        'mode': 'quiz',
        'current_question': question
    }
    
    text = f"🧠 Вопрос:\n{question['question']}\n\n"
    for option in question['options']:
        text += f"{option}\n"
    text += f"\nОтветьте буквой (А, Б или В)"
    await update.message.reply_text(text)

# Функция проверки ответа
async def check_quiz_answer(update: Update, user_answer: str):
    user_id = update.effective_user.id
    username = update.effective_user.first_name or "Аноним"
    
    if user_id not in user_states or user_states[user_id]['mode'] != 'quiz':
        return False
    
    # Инициализация счета пользователя если его нет
    if user_id not in user_scores:
        user_scores[user_id] = {
            'name': username,
            'correct': 0,
            'incorrect': 0,
            'total': 0
        }
    
    correct_answer = user_states[user_id]['current_question']['answer']
    user_answer = user_answer.upper().strip()
    
    # Обновляем статистику
    user_scores[user_id]['total'] += 1
    
    if user_answer == correct_answer:
        user_scores[user_id]['correct'] += 1
        score = user_scores[user_id]
        percentage = round((score['correct'] / score['total']) * 100, 1)
        await update.message.reply_text(
            f"✅ Правильно! Отличная работа! 🎉\n\n"
            f"📊 Ваша статистика:\n"
            f"Правильных ответов: {score['correct']}\n"
            f"Всего вопросов: {score['total']}\n"
            f"Процент правильных: {percentage}%",
            reply_markup=get_main_keyboard()
        )
    else:
        user_scores[user_id]['incorrect'] += 1
        score = user_scores[user_id]
        percentage = round((score['correct'] / score['total']) * 100, 1)
        await update.message.reply_text(
            f"❌ Неверно. Правильный ответ: {correct_answer}\n\n"
            f"📊 Ваша статистика:\n"
            f"Правильных ответов: {score['correct']}\n"
            f"Всего вопросов: {score['total']}\n"
            f"Процент правильных: {percentage}%",
            reply_markup=get_main_keyboard()
        )
    
    # Очищаем состояние пользователя
    del user_states[user_id]
    return True

# Функция показа рейтинга
async def show_leaderboard(update: Update):
    if not user_scores:
        await update.message.reply_text(
            "🏆 Рейтинг пуст. Начните викторину, чтобы попасть в топ!",
            reply_markup=get_main_keyboard()
        )
        return
    
    # Сортируем по проценту правильных ответов, затем по количеству правильных
    sorted_users = sorted(
        user_scores.items(),
        key=lambda x: (x[1]['correct'] / max(x[1]['total'], 1), x[1]['correct']),
        reverse=True
    )
    
    text = "🏆 Топ-10 участников:\n\n"
    for i, (user_id, score) in enumerate(sorted_users[:10], 1):
        percentage = round((score['correct'] / max(score['total'], 1)) * 100, 1)
        text += f"{i}. {score['name']} - {percentage}% ({score['correct']}/{score['total']})\n"
    
    await update.message.reply_text(text, reply_markup=get_main_keyboard())

# Команда /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_name = update.effective_user.first_name or "друг"
    welcome_text = (
        f"👋 Привет, {user_name}! Добро пожаловать в экономическую викторину!\n\n"
        f"🧠 Проверьте свои знания в области экономики\n"
        f"📊 Отслеживайте свою статистику\n"
        f"🏆 Соревнуйтесь с другими участниками\n\n"
        f"Используйте кнопки ниже для навигации или команды:\n"
        f"/quiz - начать викторину\n"
        f"/stats - посмотреть статистику\n"
        f"/leaderboard - рейтинг участников\n"
        f"/help - помощь"
    )
    await update.message.reply_text(welcome_text, reply_markup=get_main_keyboard())

# Команда /quiz
async def quiz_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await quiz_question(update)

# Команда /stats
async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if user_id not in user_scores:
        await update.message.reply_text(
            "📊 У вас пока нет статистики. Начните викторину!",
            reply_markup=get_main_keyboard()
        )
        return
    
    score = user_scores[user_id]
    percentage = round((score['correct'] / max(score['total'], 1)) * 100, 1)
    
    stats_text = (
        f"📊 Ваша статистика:\n\n"
        f"👤 Имя: {score['name']}\n"
        f"✅ Правильных ответов: {score['correct']}\n"
        f"❌ Неправильных ответов: {score['incorrect']}\n"
        f"📝 Всего вопросов: {score['total']}\n"
        f"📈 Процент правильных: {percentage}%\n\n"
    )
    
    # Определяем уровень знаний
    if percentage >= 90:
        stats_text += "🏆 Уровень: Эксперт по экономике!"
    elif percentage >= 75:
        stats_text += "🥇 Уровень: Продвинутый"
    elif percentage >= 60:
        stats_text += "🥈 Уровень: Хороший"
    elif percentage >= 40:
        stats_text += "🥉 Уровень: Базовый"
    else:
        stats_text += "📚 Уровень: Начинающий"
    
    await update.message.reply_text(stats_text, reply_markup=get_main_keyboard())

# Команда /leaderboard
async def leaderboard_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_leaderboard(update)

# Команда /help
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = (
        "❓ Помощь по боту:\n\n"
        "🧠 <b>Викторина</b>:\n"
        "• Нажмите 'Начать викторину' или используйте /quiz\n"
        "• Отвечайте буквами А, Б или В\n"
        "• Каждый ответ засчитывается в статистику\n\n"
        "📊 <b>Статистика</b>:\n"
        "• Нажмите 'Моя статистика' или используйте /stats\n"
        "• Просматривайте свои результаты и уровень\n\n"
        "🏆 <b>Рейтинг</b>:\n"
        "• Нажмите 'Рейтинг' или используйте /leaderboard\n"
        "• Смотрите топ-10 лучших участников\n\n"
        "💡 <b>Советы</b>:\n"
        "• Чем больше вопросов отвечаете, тем точнее статистика\n"
        "• Рейтинг основан на проценте правильных ответов\n"
        "• При равном проценте учитывается общее количество правильных ответов"
    )
    await update.message.reply_text(help_text, parse_mode='HTML', reply_markup=get_main_keyboard())

# Обработчик текстовых сообщений
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    
    # Проверяем, находится ли пользователь в режиме викторины
    if await check_quiz_answer(update, text):
        return
    
    # Обработка кнопок клавиатуры
    if text == "🧠 Начать викторину":
        await quiz_question(update)
    elif text == "📊 Моя статистика":
        await stats_command(update, context)
    elif text == "🏆 Рейтинг":
        await leaderboard_command(update, context)
    elif text == "❓ Помощь":
        await help_command(update, context)
    else:
        # Если сообщение не распознано
        await update.message.reply_text(
            "🤔 Не понимаю команду. Используйте кнопки меню или команду /help для получения помощи.",
            reply_markup=get_main_keyboard()
        )

# Функция для обработки ошибок
async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    print(f"Exception while handling an update: {context.error}")

# Основная функция
def main():
    if not TOKEN:
        print("❌ Ошибка: Не найден токен бота. Проверьте переменную окружения TELEGRAM_BOT_TOKEN")
        return
    
    print("🤖 Запуск экономического викторина-бота...")
    
    # Создаем приложение
    application = Application.builder().token(TOKEN).build()
    
    # Добавляем обработчики команд
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("quiz", quiz_command))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("leaderboard", leaderboard_command))
    application.add_handler(CommandHandler("help", help_command))
    
    # Добавляем обработчик текстовых сообщений
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Добавляем обработчик ошибок
    application.add_error_handler(error_handler)
    
    # Запускаем бота
    print("✅ Бот запущен и готов к работе!")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
