import os
import asyncio
import logging
from dotenv import load_dotenv
import random

# Load environment variables
load_dotenv()
TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')

# State management
user_states = {}
user_scores = {}

# Quiz questions
quiz_questions = [
    {
        "question": "Что такое ВВП?",
        "options": ["А) Валовой внутренний продукт", "Б) Валовой внешний продукт", "В) Внутренний валовой процент"],
        "answer": "А"
    },
    {
        "question": "Что такое флотирование валюты?",
        "options": ["А) Установленный курс", "Б) Свободное установление курса", "В) Поддержка курса"],
        "answer": "Б"
    },
    {
        "question": "Какой из следующих показателей является опережающим индикатором?",
        "options": ["А) Уровень безработицы", "Б) Индекс производственной активности", "В) Инфляция"],
        "answer": "Б"
    },
    {
        "question": "Что такое валютный курс?",
        "options": ["А) Цена одной валюты в терминах другой", "Б) Уровень инфляции в стране", "В) Рейтинг финансовых институтов"],
        "answer": "А"
    },
    {
        "question": "Какое влияние оказывает снижение процентной ставки?",
        "options": ["А) Увеличивает инвестиции", "Б) Увеличивает инфляцию", "В) Снижает спрос на кредит"],
        "answer": "А"
    },
    {
        "question": "Что такое экономический цикл?",
        "options": ["А) Периоды роста и спада экономики", "Б) Устойчивое экономическое развитие", "В) Нестабильность цен"],
        "answer": "А"
    },
    {
        "question": "Что такое дефляция?",
        "options": ["А) Рост цен", "Б) Снижение цен", "В) Стабильность цен"],
        "answer": "Б"
    },
    {
        "question": "Какой показатель характеризует безработицу?",
        "options": ["А) Уровень безработицы", "Б) Индекс цен", "В) Валютный курс"],
        "answer": "А"
    },
    {
        "question": "Что такое девальвация рубля?",
        "options": ["А) Укрепление рубля", "Б) Ослабление рубля", "В) Стабильность курса"],
        "answer": "Б"
    },
    {
        "question": "Что показывает индекс потребительских цен?",
        "options": ["А) Динамику цен на товары и услуги", "Б) Уровень безработицы", "В) Объём экспорта"],
        "answer": "А"
    },
    {
        "question": "Что такое рецессия?",
        "options": ["А) Экономический рост", "Б) Экономический спад", "В) Стабильная экономика"],
        "answer": "Б"
    },
    {
        "question": "Что такое фискальная политика?",
        "options": ["А) Политика в области налогов и расходов", "Б) Денежная политика", "В) Торговая политика"],
        "answer": "А"
    },
    {
        "question": "Какой налог является прямым?",
        "options": ["А) НДС", "Б) Подоходный налог", "В) Акциз"],
        "answer": "Б"
    },
    {
        "question": "Что показывает коэффициент Джини?",
        "options": ["А) Уровень инфляции", "Б) Неравенство доходов", "В) Экономический рост"],
        "answer": "Б"
    },
    {
        "question": "Что такое стагфляция?",
        "options": ["А) Рост + инфляция", "Б) Спад + дефляция", "В) Стагнация + инфляция"],
        "answer": "В"
    },
    {
        "question": "Какой вид безработицы связан с поиском новой работы?",
        "options": ["А) Структурная", "Б) Фрикционная", "В) Циклическая"],
        "answer": "Б"
    },
    {
        "question": "Что такое ликвидность?",
        "options": ["А) Способность активов превращаться в деньги", "Б) Доходность инвестиций", "В) Уровень риска"],
        "answer": "А"
    }
]

# Simple HTTP-based bot using webhooks
import json
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.request
import urllib.parse

class TelegramBot:
    def __init__(self, token):
        self.token = token
        self.api_url = f"https://api.telegram.org/bot{token}"
    
    def send_message(self, chat_id, text, reply_markup=None):
        """Send message to Telegram chat"""
        data = {
            'chat_id': chat_id,
            'text': text,
            'parse_mode': 'HTML'
        }
        
        if reply_markup:
            data['reply_markup'] = json.dumps(reply_markup)
        
        try:
            req_data = urllib.parse.urlencode(data).encode()
            request = urllib.request.Request(f"{self.api_url}/sendMessage", data=req_data)
            response = urllib.request.urlopen(request)
            return json.loads(response.read().decode())
        except Exception as e:
            print(f"Error sending message: {e}")
            return None
    
    def get_main_keyboard(self):
        """Get main keyboard markup"""
        return {
            'keyboard': [
                [{'text': '🧠 Начать викторину'}, {'text': '📊 Моя статистика'}],
                [{'text': '🏆 Рейтинг'}, {'text': '❓ Помощь'}]
            ],
            'resize_keyboard': True
        }
    
    def quiz_question(self, chat_id):
        """Send quiz question"""
        question = random.choice(quiz_questions)
        
        # Save user state
        user_states[chat_id] = {
            'mode': 'quiz',
            'current_question': question
        }
        
        text = f"🧠 Вопрос:\n{question['question']}\n\n"
        for option in question['options']:
            text += f"{option}\n"
        text += f"\nОтветьте буквой (А, Б или В)"
        
        self.send_message(chat_id, text)
    
    def check_quiz_answer(self, chat_id, username, user_answer):
        """Check quiz answer"""
        if chat_id not in user_states or user_states[chat_id]['mode'] != 'quiz':
            return False
        
        # Initialize user score if not exists
        if chat_id not in user_scores:
            user_scores[chat_id] = {
                'name': username or "Аноним",
                'correct': 0,
                'incorrect': 0,
                'total': 0
            }
        
        correct_answer = user_states[chat_id]['current_question']['answer']
        user_answer = user_answer.upper().strip()
        
        # Update statistics
        user_scores[chat_id]['total'] += 1
        
        if user_answer == correct_answer:
            user_scores[chat_id]['correct'] += 1
            score = user_scores[chat_id]
            percentage = round((score['correct'] / score['total']) * 100, 1)
            text = (
                f"✅ Правильно! Отличная работа! 🎉\n\n"
                f"📊 Ваша статистика:\n"
                f"Правильных ответов: {score['correct']}\n"
                f"Всего вопросов: {score['total']}\n"
                f"Процент правильных: {percentage}%"
            )
        else:
            user_scores[chat_id]['incorrect'] += 1
            score = user_scores[chat_id]
            percentage = round((score['correct'] / score['total']) * 100, 1)
            text = (
                f"❌ Неверно. Правильный ответ: {correct_answer}\n\n"
                f"📊 Ваша статистика:\n"
                f"Правильных ответов: {score['correct']}\n"
                f"Всего вопросов: {score['total']}\n"
                f"Процент правильных: {percentage}%"
            )
        
        self.send_message(chat_id, text, self.get_main_keyboard())
        
        # Clear user state
        del user_states[chat_id]
        return True
    
    def show_leaderboard(self, chat_id):
        """Show leaderboard"""
        if not user_scores:
            self.send_message(
                chat_id, 
                "🏆 Рейтинг пуст. Начните викторину, чтобы попасть в топ!",
                self.get_main_keyboard()
            )
            return
        
        # Sort by percentage, then by correct answers
        sorted_users = sorted(
            user_scores.items(),
            key=lambda x: (x[1]['correct'] / max(x[1]['total'], 1), x[1]['correct']),
            reverse=True
        )
        
        text = "🏆 Топ-10 участников:\n\n"
        for i, (user_id, score) in enumerate(sorted_users[:10], 1):
            percentage = round((score['correct'] / max(score['total'], 1)) * 100, 1)
            text += f"{i}. {score['name']} - {percentage}% ({score['correct']}/{score['total']})\n"
        
        self.send_message(chat_id, text, self.get_main_keyboard())
    
    def show_stats(self, chat_id):
        """Show user statistics"""
        if chat_id not in user_scores:
            self.send_message(
                chat_id,
                "📊 У вас пока нет статистики. Начните викторину!",
                self.get_main_keyboard()
            )
            return
        
        score = user_scores[chat_id]
        percentage = round((score['correct'] / max(score['total'], 1)) * 100, 1)
        
        stats_text = (
            f"📊 Ваша статистика:\n\n"
            f"👤 Имя: {score['name']}\n"
            f"✅ Правильных ответов: {score['correct']}\n"
            f"❌ Неправильных ответов: {score['incorrect']}\n"
            f"📝 Всего вопросов: {score['total']}\n"
            f"📈 Процент правильных: {percentage}%\n\n"
        )
        
        # Determine skill level
        if percentage >= 90:
            stats_text += "🏆 Уровень: Эксперт по экономике!"
        elif percentage >= 75:
            stats_text += "🥇 Уровень: Продвинутый"
        elif percentage >= 60:
            stats_text += "🥈 Уровень: Хороший"
        elif percentage >= 40:
            stats_text += "🥉 Уровень: Базовый"
        else:
            stats_text += "📚 Уровень: Начинающий"
        
        self.send_message(chat_id, stats_text, self.get_main_keyboard())
    
    def send_help(self, chat_id):
        """Send help message"""
        help_text = (
            "❓ Помощь по боту:\n\n"
            "🧠 <b>Викторина</b>:\n"
            "• Нажмите 'Начать викторину'\n"
            "• Отвечайте буквами А, Б или В\n"
            "• Каждый ответ засчитывается в статистику\n\n"
            "📊 <b>Статистика</b>:\n"
            "• Нажмите 'Моя статистика'\n"
            "• Просматривайте свои результаты и уровень\n\n"
            "🏆 <b>Рейтинг</b>:\n"
            "• Нажмите 'Рейтинг'\n"
            "• Смотрите топ-10 лучших участников\n\n"
            "💡 <b>Советы</b>:\n"
            "• Чем больше вопросов отвечаете, тем точнее статистика\n"
            "• Рейтинг основан на проценте правильных ответов\n"
            "• При равном проценте учитывается общее количество правильных ответов"
        )
        self.send_message(chat_id, help_text, self.get_main_keyboard())
    
    def send_start(self, chat_id, username):
        """Send start message"""
        user_name = username or "друг"
        welcome_text = (
            f"👋 Привет, {user_name}! Добро пожаловать в экономическую викторину!\n\n"
            f"🧠 Проверьте свои знания в области экономики\n"
            f"📊 Отслеживайте свою статистику\n"
            f"🏆 Соревнуйтесь с другими участниками\n\n"
            f"Используйте кнопки ниже для навигации!"
        )
        self.send_message(chat_id, welcome_text, self.get_main_keyboard())
    
    def handle_message(self, chat_id, text, username):
        """Handle incoming message"""
        # Check if user is in quiz mode
        if self.check_quiz_answer(chat_id, username, text):
            return
        
        # Handle button commands
        if text == "🧠 Начать викторину":
            self.quiz_question(chat_id)
        elif text == "📊 Моя статистика":
            self.show_stats(chat_id)
        elif text == "🏆 Рейтинг":
            self.show_leaderboard(chat_id)
        elif text == "❓ Помощь":
            self.send_help(chat_id)
        elif text == "/start":
            self.send_start(chat_id, username)
        elif text == "/quiz":
            self.quiz_question(chat_id)
        elif text == "/stats":
            self.show_stats(chat_id)
        elif text == "/leaderboard":
            self.show_leaderboard(chat_id)
        elif text == "/help":
            self.send_help(chat_id)
        else:
            # Unknown command
            self.send_message(
                chat_id,
                "🤔 Не понимаю команду. Используйте кнопки меню или /help для получения помощи.",
                self.get_main_keyboard()
            )

class WebhookHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))
            
            if 'message' in data:
                message = data['message']
                chat_id = message['chat']['id']
                text = message.get('text', '')
                username = message.get('from', {}).get('first_name', '')
                
                bot.handle_message(chat_id, text, username)
            
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b'OK')
        except Exception as e:
            print(f"Error handling webhook: {e}")
            self.send_response(500)
            self.end_headers()

def run_polling():
    """Run bot in polling mode"""
    offset = 0
    
    while True:
        try:
            # Get updates
            url = f"{bot.api_url}/getUpdates?offset={offset}&timeout=30"
            response = urllib.request.urlopen(url)
            data = json.loads(response.read().decode())
            
            if data['ok']:
                for update in data['result']:
                    offset = update['update_id'] + 1
                    
                    if 'message' in update:
                        message = update['message']
                        chat_id = message['chat']['id']
                        text = message.get('text', '')
                        username = message.get('from', {}).get('first_name', '')
                        
                        bot.handle_message(chat_id, text, username)
        
        except Exception as e:
            print(f"Polling error: {e}")
            import time
            time.sleep(5)

if __name__ == "__main__":
    if not TOKEN:
        print("❌ Ошибка: Не найден токен бота. Проверьте переменную окружения TELEGRAM_BOT_TOKEN")
        exit(1)
    
    print("🤖 Запуск экономического викторина-бота...")
    bot = TelegramBot(TOKEN)
    
    # Test bot connection
    try:
        response = urllib.request.urlopen(f"{bot.api_url}/getMe")
        data = json.loads(response.read().decode())
        if data['ok']:
            print(f"✅ Бот подключен: @{data['result']['username']}")
        else:
            print("❌ Ошибка подключения к боту")
            exit(1)
    except Exception as e:
        print(f"❌ Ошибка подключения: {e}")
        exit(1)
    
    print("🔄 Запуск в режиме polling...")
    run_polling()